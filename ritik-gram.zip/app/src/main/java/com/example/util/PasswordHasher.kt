package com.example.util

import java.security.MessageDigest

object PasswordHasher {
    private const val SALT = "RitikGramSecureSalt_2026_#"

    fun hashPassword(password: String): String {
        val input = password + SALT
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(password: String, storedHash: String): Boolean {
        val computedHash = hashPassword(password)
        return computedHash == storedHash
    }
}
