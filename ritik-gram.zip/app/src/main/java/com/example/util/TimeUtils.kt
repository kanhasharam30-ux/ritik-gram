package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object TimeUtils {
    private val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("MMM d", Locale.getDefault())
    private val fullDateFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())

    fun formatMessageTime(timestamp: Long): String {
        return timeFormat.format(Date(timestamp))
    }

    fun formatConversationTime(timestamp: Long): String {
        val now = Calendar.getInstance()
        val messageDate = Calendar.getInstance().apply { timeInMillis = timestamp }

        return when {
            isSameDay(now, messageDate) -> timeFormat.format(Date(timestamp))
            isYesterday(now, messageDate) -> "Yesterday"
            now.get(Calendar.YEAR) == messageDate.get(Calendar.YEAR) -> dateFormat.format(Date(timestamp))
            else -> fullDateFormat.format(Date(timestamp))
        }
    }

    fun formatLastSeen(timestamp: Long, isOnline: Boolean, privacy: String): String {
        if (privacy.equals("NOBODY", ignoreCase = true)) {
            return ""
        }
        if (isOnline) {
            return "Online"
        }
        val diffMinutes = (System.currentTimeMillis() - timestamp) / (1000 * 60)
        return when {
            diffMinutes < 1 -> "Last seen just now"
            diffMinutes < 60 -> "Last seen ${diffMinutes}m ago"
            diffMinutes < 1440 -> {
                val cal = Calendar.getInstance().apply { timeInMillis = timestamp }
                "Last seen today at ${timeFormat.format(cal.time)}"
            }
            else -> "Last seen ${dateFormat.format(Date(timestamp))}"
        }
    }

    private fun isSameDay(cal1: Calendar, cal2: Calendar): Boolean {
        return cal1.get(Calendar.ERA) == cal2.get(Calendar.ERA) &&
                cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
    }

    private fun isYesterday(today: Calendar, other: Calendar): Boolean {
        val clone = today.clone() as Calendar
        clone.add(Calendar.DAY_OF_YEAR, -1)
        return isSameDay(clone, other)
    }
}
