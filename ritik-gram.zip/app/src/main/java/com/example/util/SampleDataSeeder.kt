package com.example.util

import com.example.data.local.AppDatabase
import com.example.data.model.ConversationEntity
import com.example.data.model.MessageEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

object SampleDataSeeder {
    // Preset user IDs
    const val USER_RITIK_ID = "user_ritik_001"
    const val USER_PRIYA_ID = "user_priya_002"
    const val USER_ALEX_ID = "user_alex_003"
    const val USER_NEHA_ID = "user_neha_004"

    suspend fun seedInitialData(database: AppDatabase) = withContext(Dispatchers.IO) {
        val userDao = database.userDao()
        val conversationDao = database.conversationDao()
        val messageDao = database.messageDao()

        // Check if users already exist
        val existing = userDao.getUserByIdSync(USER_RITIK_ID)
        if (existing != null) return@withContext

        val now = System.currentTimeMillis()

        val ritik = UserEntity(
            id = USER_RITIK_ID,
            username = "ritik",
            displayName = "Ritik Sharma",
            email = "ritik@ritikgram.app",
            phone = "+91 9876543210",
            passwordHash = PasswordHasher.hashPassword("ritik123"),
            avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
            bio = "Founder & Architect of Ritik Gram 🚀 Welcome to modern social messaging!",
            isOnline = true,
            lastSeenTimestamp = now,
            securityQuestion = "What is your favorite color?",
            securityAnswerHash = PasswordHasher.hashPassword("blue")
        )

        val priya = UserEntity(
            id = USER_PRIYA_ID,
            username = "priya",
            displayName = "Priya Patel",
            email = "priya@ritikgram.app",
            phone = "+91 9876543211",
            passwordHash = PasswordHasher.hashPassword("priya123"),
            avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80",
            bio = "Visual storyteller & travel photographer 📸 Loving the new Ritik Gram design!",
            isOnline = true,
            lastSeenTimestamp = now - 1000 * 60 * 5,
            securityQuestion = "What is your favorite color?",
            securityAnswerHash = PasswordHasher.hashPassword("purple")
        )

        val alex = UserEntity(
            id = USER_ALEX_ID,
            username = "alex",
            displayName = "Alex Morgan",
            email = "alex@ritikgram.app",
            phone = "+91 9876543212",
            passwordHash = PasswordHasher.hashPassword("alex123"),
            avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80",
            bio = "Product designer & UI craftsman 🎨 Clean typography is everything.",
            isOnline = false,
            lastSeenTimestamp = now - 1000 * 60 * 35,
            securityQuestion = "What is your favorite color?",
            securityAnswerHash = PasswordHasher.hashPassword("indigo")
        )

        val neha = UserEntity(
            id = USER_NEHA_ID,
            username = "neha",
            displayName = "Neha Gupta",
            email = "neha@ritikgram.app",
            phone = "+91 9876543213",
            passwordHash = PasswordHasher.hashPassword("neha123"),
            avatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80",
            bio = "Music, podcasts & late night vibes 🎵 Connect with me here!",
            isOnline = false,
            lastSeenTimestamp = now - 1000 * 60 * 120,
            securityQuestion = "What is your favorite color?",
            securityAnswerHash = PasswordHasher.hashPassword("pink")
        )

        userDao.insertUser(ritik)
        userDao.insertUser(priya)
        userDao.insertUser(alex)
        userDao.insertUser(neha)

        // Seed Conversation: Ritik <-> Priya
        val convId1 = getConversationId(USER_RITIK_ID, USER_PRIYA_ID)
        val conv1 = ConversationEntity(
            id = convId1,
            user1Id = USER_RITIK_ID,
            user2Id = USER_PRIYA_ID,
            lastMessageText = "The real-time messaging feels super smooth! ✨",
            lastMessageTimestamp = now - 1000 * 60 * 2,
            lastMessageSenderId = USER_PRIYA_ID,
            unreadCountUser1 = 1,
            unreadCountUser2 = 0
        )
        conversationDao.upsertConversation(conv1)

        val msg1 = MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = convId1,
            senderId = USER_RITIK_ID,
            receiverId = USER_PRIYA_ID,
            messageText = "Hey Priya! Welcome to Ritik Gram 🌟 How do you like the new interface?",
            timestamp = now - 1000 * 60 * 15,
            status = "READ",
            reactionEmoji = "🔥"
        )
        val msg2 = MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = convId1,
            senderId = USER_PRIYA_ID,
            receiverId = USER_RITIK_ID,
            messageText = "Hey Ritik! The blue and purple gradient theme looks absolutely stunning!",
            timestamp = now - 1000 * 60 * 10,
            status = "READ",
            reactionEmoji = "❤️"
        )
        val msg3 = MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = convId1,
            senderId = USER_PRIYA_ID,
            receiverId = USER_RITIK_ID,
            messageText = "The real-time messaging feels super smooth! ✨",
            timestamp = now - 1000 * 60 * 2,
            status = "DELIVERED"
        )
        messageDao.insertMessage(msg1)
        messageDao.insertMessage(msg2)
        messageDao.insertMessage(msg3)

        // Seed Conversation: Ritik <-> Alex
        val convId2 = getConversationId(USER_RITIK_ID, USER_ALEX_ID)
        val conv2 = ConversationEntity(
            id = convId2,
            user1Id = USER_RITIK_ID,
            user2Id = USER_ALEX_ID,
            lastMessageText = "Let's review the new profile customizer later today.",
            lastMessageTimestamp = now - 1000 * 60 * 45,
            lastMessageSenderId = USER_ALEX_ID,
            unreadCountUser1 = 0,
            unreadCountUser2 = 0
        )
        conversationDao.upsertConversation(conv2)

        val msgAlex = MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = convId2,
            senderId = USER_ALEX_ID,
            receiverId = USER_RITIK_ID,
            messageText = "Let's review the new profile customizer later today.",
            timestamp = now - 1000 * 60 * 45,
            status = "READ",
            reactionEmoji = "👍"
        )
        messageDao.insertMessage(msgAlex)
    }

    fun getConversationId(userA: String, userB: String): String {
        return if (userA < userB) "${userA}_$userB" else "${userB}_$userA"
    }
}
