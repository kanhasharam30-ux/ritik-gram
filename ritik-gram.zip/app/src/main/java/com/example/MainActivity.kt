package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.repository.AuthRepository
import com.example.data.repository.ChatRepository
import com.example.data.repository.UserRepository
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.auth.AuthViewModel
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.chat.ChatViewModel
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.home.HomeViewModel
import com.example.ui.screens.home.NavigationTab
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.profile.ProfileViewModel
import com.example.ui.screens.search.SearchUsersScreen
import com.example.ui.screens.search.SearchViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.util.SampleDataSeeder
import kotlinx.coroutines.launch

sealed interface AppDestination {
    data object Home : AppDestination
    data class Chat(val otherUserId: String) : AppDestination
    data object Search : AppDestination
    data object Profile : AppDestination
}

class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase
    private lateinit var authRepository: AuthRepository
    private lateinit var chatRepository: ChatRepository
    private lateinit var userRepository: UserRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        database = AppDatabase.getInstance(this)
        authRepository = AuthRepository(database.userDao(), this)
        chatRepository = ChatRepository(database.conversationDao(), database.messageDao(), database.userDao())
        userRepository = UserRepository(database.userDao(), database.blockedUserDao())

        // Seed initial mock accounts and sample chats asynchronously
        lifecycleScope.launch {
            SampleDataSeeder.seedInitialData(database)
        }

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RitikGramApp(
                        authRepository = authRepository,
                        chatRepository = chatRepository,
                        userRepository = userRepository
                    )
                }
            }
        }
    }
}

@Composable
fun RitikGramApp(
    authRepository: AuthRepository,
    chatRepository: ChatRepository,
    userRepository: UserRepository
) {
    val authViewModel: AuthViewModel = viewModel(
        factory = AuthViewModel.provideFactory(authRepository)
    )
    val currentUserId by authViewModel.currentUserId.collectAsState()

    var currentDestination by remember { mutableStateOf<AppDestination>(AppDestination.Home) }

    if (currentUserId == null) {
        // Authenticate User
        AuthScreen(
            viewModel = authViewModel,
            onAuthSuccess = {
                currentDestination = AppDestination.Home
            }
        )
    } else {
        val uid = currentUserId!!

        when (val dest = currentDestination) {
            is AppDestination.Home -> {
                val homeViewModel: HomeViewModel = viewModel(
                    key = "home_$uid",
                    factory = HomeViewModel.provideFactory(uid, chatRepository, userRepository)
                )

                HomeScreen(
                    currentUserId = uid,
                    viewModel = homeViewModel,
                    onOpenChat = { otherId ->
                        currentDestination = AppDestination.Chat(otherId)
                    },
                    onNavigateSearch = {
                        currentDestination = AppDestination.Search
                    },
                    onNavigateProfile = {
                        currentDestination = AppDestination.Profile
                    },
                    onNewChatClick = {
                        currentDestination = AppDestination.Search
                    }
                )
            }

            is AppDestination.Chat -> {
                BackHandler {
                    currentDestination = AppDestination.Home
                }

                val chatViewModel: ChatViewModel = viewModel(
                    key = "chat_${uid}_${dest.otherUserId}",
                    factory = ChatViewModel.provideFactory(uid, dest.otherUserId, chatRepository, userRepository)
                )

                ChatScreen(
                    viewModel = chatViewModel,
                    onNavigateBack = {
                        currentDestination = AppDestination.Home
                    }
                )
            }

            is AppDestination.Search -> {
                BackHandler {
                    currentDestination = AppDestination.Home
                }

                val searchViewModel: SearchViewModel = viewModel(
                    key = "search_$uid",
                    factory = SearchViewModel.provideFactory(uid, userRepository)
                )

                SearchUsersScreen(
                    viewModel = searchViewModel,
                    onUserSelected = { otherId ->
                        currentDestination = AppDestination.Chat(otherId)
                    },
                    onNavigateBack = {
                        currentDestination = AppDestination.Home
                    }
                )
            }

            is AppDestination.Profile -> {
                BackHandler {
                    currentDestination = AppDestination.Home
                }

                val profileViewModel: ProfileViewModel = viewModel(
                    key = "profile_$uid",
                    factory = ProfileViewModel.provideFactory(uid, userRepository, authRepository)
                )

                ProfileScreen(
                    viewModel = profileViewModel,
                    onNavigateBack = {
                        currentDestination = AppDestination.Home
                    },
                    onLoggedOut = {
                        currentDestination = AppDestination.Home
                    }
                )
            }
        }
    }
}
