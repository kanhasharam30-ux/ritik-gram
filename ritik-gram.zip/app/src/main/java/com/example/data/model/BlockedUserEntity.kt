package com.example.data.model

import androidx.room.Entity

@Entity(
    tableName = "blocked_users",
    primaryKeys = ["blockerId", "blockedUserId"]
)
data class BlockedUserEntity(
    val blockerId: String,
    val blockedUserId: String,
    val timestamp: Long = System.currentTimeMillis()
)
