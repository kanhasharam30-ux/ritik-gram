package com.example.data.repository

import com.example.data.local.ConversationDao
import com.example.data.local.MessageDao
import com.example.data.local.UserDao
import com.example.data.model.ConversationEntity
import com.example.data.model.ConversationWithParticipant
import com.example.data.model.MessageEntity
import com.example.util.SampleDataSeeder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.withContext
import java.util.UUID

class ChatRepository(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val userDao: UserDao
) {
    fun getConversationsWithParticipants(currentUserId: String): Flow<List<ConversationWithParticipant>> {
        val conversationsFlow = conversationDao.getConversationsForUser(currentUserId)
        val allUsersFlow = userDao.getAllUsers()

        return combine(conversationsFlow, allUsersFlow) { conversations, users ->
            val userMap = users.associateBy { it.id }
            conversations.mapNotNull { conv ->
                val otherId = conv.getOtherUserId(currentUserId)
                val otherUser = userMap[otherId]
                if (otherUser != null) {
                    ConversationWithParticipant(conversation = conv, participant = otherUser)
                } else null
            }
        }.distinctUntilChanged()
    }

    fun getMessagesForConversation(conversationId: String): Flow<List<MessageEntity>> {
        return messageDao.getMessagesForConversation(conversationId)
    }

    suspend fun getOrCreateConversation(currentUserId: String, otherUserId: String): ConversationEntity = withContext(Dispatchers.IO) {
        val convId = SampleDataSeeder.getConversationId(currentUserId, otherUserId)
        val existing = conversationDao.getConversationByIdSync(convId)
        if (existing != null) return@withContext existing

        val newConv = ConversationEntity(
            id = convId,
            user1Id = if (currentUserId < otherUserId) currentUserId else otherUserId,
            user2Id = if (currentUserId < otherUserId) otherUserId else currentUserId,
            lastMessageText = "",
            lastMessageTimestamp = System.currentTimeMillis()
        )
        conversationDao.upsertConversation(newConv)
        newConv
    }

    suspend fun sendMessage(
        senderId: String,
        receiverId: String,
        text: String,
        mediaType: String = "NONE",
        mediaUrl: String = ""
    ): MessageEntity = withContext(Dispatchers.IO) {
        val convId = SampleDataSeeder.getConversationId(senderId, receiverId)
        val now = System.currentTimeMillis()

        val message = MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = convId,
            senderId = senderId,
            receiverId = receiverId,
            messageText = text.trim(),
            mediaType = mediaType,
            mediaUrl = mediaUrl,
            timestamp = now,
            status = "SENT"
        )
        messageDao.insertMessage(message)

        // Update conversation metadata
        val existingConv = conversationDao.getConversationByIdSync(convId)
        val displayLastText = when (mediaType) {
            "IMAGE" -> "📷 Photo: ${text.ifBlank { "Sent an image" }}"
            "VIDEO" -> "🎥 Video: ${text.ifBlank { "Sent a video" }}"
            "AUDIO" -> "🎤 Voice message"
            else -> text
        }

        val updatedConv = if (existingConv != null) {
            val isUser1 = existingConv.user1Id == senderId
            existingConv.copy(
                lastMessageText = displayLastText,
                lastMessageTimestamp = now,
                lastMessageSenderId = senderId,
                unreadCountUser1 = if (isUser1) existingConv.unreadCountUser1 else existingConv.unreadCountUser1 + 1,
                unreadCountUser2 = if (isUser1) existingConv.unreadCountUser2 + 1 else existingConv.unreadCountUser2
            )
        } else {
            val isUser1 = senderId < receiverId
            ConversationEntity(
                id = convId,
                user1Id = if (isUser1) senderId else receiverId,
                user2Id = if (isUser1) receiverId else senderId,
                lastMessageText = displayLastText,
                lastMessageTimestamp = now,
                lastMessageSenderId = senderId,
                unreadCountUser1 = if (isUser1) 0 else 1,
                unreadCountUser2 = if (isUser1) 1 else 0
            )
        }
        conversationDao.upsertConversation(updatedConv)

        // Mark as DELIVERED after short delay simulation
        messageDao.updateStatus(message.id, "DELIVERED")

        message
    }

    suspend fun markConversationRead(conversationId: String, currentUserId: String) = withContext(Dispatchers.IO) {
        messageDao.markAllAsRead(conversationId, receiverId = currentUserId)
        conversationDao.clearUnreadForUser1(conversationId, currentUserId)
        conversationDao.clearUnreadForUser2(conversationId, currentUserId)
    }

    suspend fun setReaction(messageId: String, reactionEmoji: String) = withContext(Dispatchers.IO) {
        messageDao.updateReaction(messageId, reactionEmoji)
    }

    suspend fun deleteMessage(messageId: String) = withContext(Dispatchers.IO) {
        messageDao.softDeleteMessage(messageId)
    }

    suspend fun clearConversation(conversationId: String) = withContext(Dispatchers.IO) {
        messageDao.deleteAllMessagesInConversation(conversationId)
        val conv = conversationDao.getConversationByIdSync(conversationId)
        if (conv != null) {
            conversationDao.upsertConversation(
                conv.copy(
                    lastMessageText = "Chat cleared",
                    lastMessageTimestamp = System.currentTimeMillis()
                )
            )
        }
    }

    // Helper for demo/testing two-way chats
    suspend fun simulateReply(senderId: String, receiverId: String, replyText: String) = withContext(Dispatchers.IO) {
        sendMessage(senderId = senderId, receiverId = receiverId, text = replyText)
    }
}
