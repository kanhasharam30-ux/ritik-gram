package com.example.data.repository

import com.example.data.local.BlockedUserDao
import com.example.data.local.UserDao
import com.example.data.model.BlockedUserEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class UserRepository(
    private val userDao: UserDao,
    private val blockedUserDao: BlockedUserDao
) {
    fun getUserById(userId: String): Flow<UserEntity?> = userDao.getUserById(userId)

    suspend fun getUserByIdSync(userId: String): UserEntity? = withContext(Dispatchers.IO) {
        userDao.getUserByIdSync(userId)
    }

    suspend fun getUserByUsername(username: String): UserEntity? = withContext(Dispatchers.IO) {
        val clean = username.trim().lowercase().removePrefix("@")
        userDao.getUserByUsername(clean)
    }

    fun searchUsers(query: String): Flow<List<UserEntity>> = userDao.searchUsers(query.trim())

    fun getAllOtherUsers(currentUserId: String): Flow<List<UserEntity>> = userDao.getAllOtherUsers(currentUserId)

    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsers()

    suspend fun updateProfile(
        user: UserEntity,
        newDisplayName: String,
        newBio: String,
        newAvatarUrl: String,
        newPhone: String,
        newEmail: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val updated = user.copy(
                displayName = newDisplayName.trim().ifBlank { user.displayName },
                bio = newBio.trim(),
                avatarUrl = newAvatarUrl.trim().ifBlank { user.avatarUrl },
                phone = newPhone.trim(),
                email = newEmail.trim()
            )
            userDao.updateUser(updated)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updatePrivacySettings(
        userId: String,
        lastSeen: String,
        readReceipts: Boolean,
        whoCanMessage: String
    ) = withContext(Dispatchers.IO) {
        val user = userDao.getUserByIdSync(userId) ?: return@withContext
        val updated = user.copy(
            privacyLastSeen = lastSeen,
            privacyReadReceipts = readReceipts,
            privacyWhoCanMessage = whoCanMessage
        )
        userDao.updateUser(updated)
    }

    suspend fun blockUser(blockerId: String, blockedUserId: String) = withContext(Dispatchers.IO) {
        blockedUserDao.blockUser(
            BlockedUserEntity(
                blockerId = blockerId,
                blockedUserId = blockedUserId,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun unblockUser(blockerId: String, blockedUserId: String) = withContext(Dispatchers.IO) {
        blockedUserDao.unblockUser(blockerId, blockedUserId)
    }

    suspend fun isUserBlocked(blockerId: String, otherUserId: String): Boolean = withContext(Dispatchers.IO) {
        blockedUserDao.isUserBlocked(blockerId, otherUserId)
    }

    fun getBlockedUsers(currentUserId: String): Flow<List<BlockedUserEntity>> =
        blockedUserDao.getBlockedUsers(currentUserId)
}
