package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "messages",
    indices = [
        Index(value = ["conversationId"]),
        Index(value = ["timestamp"]),
        Index(value = ["senderId"]),
        Index(value = ["receiverId"])
    ]
)
data class MessageEntity(
    @PrimaryKey
    val id: String,
    val conversationId: String,
    val senderId: String,
    val receiverId: String,
    val messageText: String,
    val mediaType: String = "NONE", // "NONE", "IMAGE", "VIDEO", "AUDIO"
    val mediaUrl: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "SENT", // "SENT", "DELIVERED", "READ"
    val reactionEmoji: String = "", // e.g. "❤️", "😂", "👍", "🔥", etc.
    val isDeleted: Boolean = false
)
