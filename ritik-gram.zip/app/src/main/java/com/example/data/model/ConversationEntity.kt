package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "conversations",
    indices = [
        Index(value = ["user1Id"]),
        Index(value = ["user2Id"]),
        Index(value = ["lastMessageTimestamp"])
    ]
)
data class ConversationEntity(
    @PrimaryKey
    val id: String, // format: min(user1Id, user2Id) + "_" + max(user1Id, user2Id)
    val user1Id: String,
    val user2Id: String,
    val lastMessageText: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val lastMessageSenderId: String = "",
    val unreadCountUser1: Int = 0,
    val unreadCountUser2: Int = 0,
    val isPinned: Boolean = false,
    val isArchived: Boolean = false
) {
    fun getOtherUserId(currentUserId: String): String {
        return if (currentUserId == user1Id) user2Id else user1Id
    }

    fun getUnreadCount(currentUserId: String): Int {
        return if (currentUserId == user1Id) unreadCountUser1 else unreadCountUser2
    }
}
