package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.local.UserDao
import com.example.data.model.UserEntity
import com.example.util.PasswordHasher
import com.example.util.SampleDataSeeder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.UUID

class AuthRepository(
    private val userDao: UserDao,
    context: Context
) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ritik_gram_auth", Context.MODE_PRIVATE)
    private val _currentUserId = MutableStateFlow<String?>(prefs.getString("logged_in_user_id", SampleDataSeeder.USER_RITIK_ID))
    val currentUserId = _currentUserId.asStateFlow()

    fun observeCurrentUser(): Flow<UserEntity?>? {
        val uid = _currentUserId.value ?: return null
        return userDao.getUserById(uid)
    }

    suspend fun getCurrentUser(): UserEntity? = withContext(Dispatchers.IO) {
        val uid = _currentUserId.value ?: return@withContext null
        userDao.getUserByIdSync(uid)
    }

    suspend fun register(
        username: String,
        displayName: String,
        email: String,
        phone: String,
        password: String,
        securityAnswer: String
    ): Result<UserEntity> = withContext(Dispatchers.IO) {
        val cleanUsername = username.trim().lowercase().removePrefix("@")
        if (cleanUsername.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Username cannot be empty"))
        }
        if (cleanUsername.length < 3) {
            return@withContext Result.failure(IllegalArgumentException("Username must be at least 3 characters"))
        }
        if (!cleanUsername.matches(Regex("^[a-z0-9_.]+$"))) {
            return@withContext Result.failure(IllegalArgumentException("Username can only contain letters, numbers, underscores and dots"))
        }
        if (password.length < 6) {
            return@withContext Result.failure(IllegalArgumentException("Password must be at least 6 characters"))
        }

        // Check uniqueness
        val existing = userDao.getUserByUsername(cleanUsername)
        if (existing != null) {
            return@withContext Result.failure(IllegalArgumentException("Username @$cleanUsername is already taken. Please choose another!"))
        }

        val newUser = UserEntity(
            id = UUID.randomUUID().toString(),
            username = cleanUsername,
            displayName = displayName.trim().ifBlank { cleanUsername },
            email = email.trim(),
            phone = phone.trim(),
            passwordHash = PasswordHasher.hashPassword(password),
            avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80",
            bio = "Hey there! I am using Ritik Gram ✨",
            isOnline = true,
            lastSeenTimestamp = System.currentTimeMillis(),
            securityQuestion = "What is your favorite color?",
            securityAnswerHash = PasswordHasher.hashPassword(securityAnswer.trim().lowercase())
        )

        try {
            userDao.insertUser(newUser)
            setSession(newUser.id)
            Result.success(newUser)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun login(credential: String, password: String): Result<UserEntity> = withContext(Dispatchers.IO) {
        val cleanCred = credential.trim().lowercase().removePrefix("@")
        if (cleanCred.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Please enter your username, email or mobile number"))
        }
        val user = userDao.getUserByLoginCredential(cleanCred)
            ?: return@withContext Result.failure(IllegalArgumentException("No account found with @$cleanCred"))

        val isPasswordCorrect = PasswordHasher.verifyPassword(password, user.passwordHash)
        if (!isPasswordCorrect) {
            return@withContext Result.failure(IllegalArgumentException("Incorrect password. Please try again!"))
        }

        // Update online status
        userDao.updateOnlineStatus(user.id, isOnline = true, lastSeen = System.currentTimeMillis())
        setSession(user.id)
        Result.success(user)
    }

    suspend fun verifySecurityAnswerAndResetPassword(
        username: String,
        securityAnswer: String,
        newPassword: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanUser = username.trim().lowercase().removePrefix("@")
        val user = userDao.getUserByUsername(cleanUser)
            ?: return@withContext Result.failure(IllegalArgumentException("No account found with @$cleanUser"))

        val isAnswerCorrect = PasswordHasher.verifyPassword(
            securityAnswer.trim().lowercase(),
            user.securityAnswerHash
        )
        if (!isAnswerCorrect) {
            return@withContext Result.failure(IllegalArgumentException("Security answer did not match. Please verify your answer."))
        }
        if (newPassword.length < 6) {
            return@withContext Result.failure(IllegalArgumentException("New password must be at least 6 characters"))
        }

        val newHash = PasswordHasher.hashPassword(newPassword)
        userDao.updatePasswordHash(user.id, newHash)
        Result.success(Unit)
    }

    suspend fun logout() = withContext(Dispatchers.IO) {
        val uid = _currentUserId.value
        if (uid != null) {
            userDao.updateOnlineStatus(uid, isOnline = false, lastSeen = System.currentTimeMillis())
        }
        prefs.edit().remove("logged_in_user_id").apply()
        _currentUserId.value = null
    }

    suspend fun switchAccount(userId: String) = withContext(Dispatchers.IO) {
        setSession(userId)
        userDao.updateOnlineStatus(userId, isOnline = true, lastSeen = System.currentTimeMillis())
    }

    private fun setSession(userId: String) {
        prefs.edit().putString("logged_in_user_id", userId).apply()
        _currentUserId.value = userId
    }
}
