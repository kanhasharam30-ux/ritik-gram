package com.example.data.model

data class ConversationWithParticipant(
    val conversation: ConversationEntity,
    val participant: UserEntity
)
