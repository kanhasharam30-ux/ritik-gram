package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "users",
    indices = [
        Index(value = ["username"], unique = true),
        Index(value = ["email"], unique = false)
    ]
)
data class UserEntity(
    @PrimaryKey
    val id: String,
    val username: String, // lowercase normalized unique handle
    val displayName: String,
    val email: String = "",
    val phone: String = "",
    val passwordHash: String,
    val avatarUrl: String = "",
    val bio: String = "Hey there! I am using Ritik Gram ✨",
    val isOnline: Boolean = true,
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val privacyLastSeen: String = "EVERYONE", // "EVERYONE", "NOBODY"
    val privacyReadReceipts: Boolean = true,
    val privacyWhoCanMessage: String = "EVERYONE", // "EVERYONE", "CONTACTS"
    val securityQuestion: String = "What is your favorite color?",
    val securityAnswerHash: String = ""
)
