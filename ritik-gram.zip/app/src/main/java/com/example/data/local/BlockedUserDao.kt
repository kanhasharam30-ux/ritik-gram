package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.BlockedUserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BlockedUserDao {
    @Query("SELECT * FROM blocked_users WHERE blockerId = :blockerId")
    fun getBlockedUsers(blockerId: String): Flow<List<BlockedUserEntity>>

    @Query("SELECT COUNT(*) > 0 FROM blocked_users WHERE blockerId = :blockerId AND blockedUserId = :blockedUserId")
    suspend fun isUserBlocked(blockerId: String, blockedUserId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun blockUser(blockedUser: BlockedUserEntity)

    @Query("DELETE FROM blocked_users WHERE blockerId = :blockerId AND blockedUserId = :blockedUserId")
    suspend fun unblockUser(blockerId: String, blockedUserId: String)
}
