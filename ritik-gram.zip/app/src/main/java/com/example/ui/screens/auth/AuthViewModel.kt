package com.example.ui.screens.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.UserEntity
import com.example.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface AuthUiState {
    data object Idle : AuthUiState
    data object Loading : AuthUiState
    data class Authenticated(val user: UserEntity) : AuthUiState
    data class Error(val message: String) : AuthUiState
    data class PasswordResetSuccess(val message: String) : AuthUiState
}

class AuthViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    val currentUserId: StateFlow<String?> = authRepository.currentUserId

    init {
        checkCurrentSession()
    }

    private fun checkCurrentSession() {
        viewModelScope.launch {
            val user = authRepository.getCurrentUser()
            if (user != null) {
                _uiState.value = AuthUiState.Authenticated(user)
            } else {
                _uiState.value = AuthUiState.Idle
            }
        }
    }

    fun login(credential: String, password: String) {
        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            val result = authRepository.login(credential, password)
            result.fold(
                onSuccess = { user ->
                    _uiState.value = AuthUiState.Authenticated(user)
                },
                onFailure = { error ->
                    _uiState.value = AuthUiState.Error(error.localizedMessage ?: "Login failed")
                }
            )
        }
    }

    fun register(
        username: String,
        displayName: String,
        email: String,
        phone: String,
        password: String,
        securityAnswer: String
    ) {
        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            val result = authRepository.register(
                username = username,
                displayName = displayName,
                email = email,
                phone = phone,
                password = password,
                securityAnswer = securityAnswer
            )
            result.fold(
                onSuccess = { user ->
                    _uiState.value = AuthUiState.Authenticated(user)
                },
                onFailure = { error ->
                    _uiState.value = AuthUiState.Error(error.localizedMessage ?: "Registration failed")
                }
            )
        }
    }

    fun resetPassword(username: String, securityAnswer: String, newPass: String) {
        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            val result = authRepository.verifySecurityAnswerAndResetPassword(username, securityAnswer, newPass)
            result.fold(
                onSuccess = {
                    _uiState.value = AuthUiState.PasswordResetSuccess("Password reset successfully! Please login with your new password.")
                },
                onFailure = { error ->
                    _uiState.value = AuthUiState.Error(error.localizedMessage ?: "Password reset failed")
                }
            )
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
            _uiState.value = AuthUiState.Idle
        }
    }

    fun switchAccount(userId: String) {
        viewModelScope.launch {
            authRepository.switchAccount(userId)
            val user = authRepository.getCurrentUser()
            if (user != null) {
                _uiState.value = AuthUiState.Authenticated(user)
            }
        }
    }

    fun clearError() {
        if (_uiState.value is AuthUiState.Error || _uiState.value is AuthUiState.PasswordResetSuccess) {
            _uiState.value = AuthUiState.Idle
        }
    }

    companion object {
        fun provideFactory(authRepository: AuthRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return AuthViewModel(authRepository) as T
                }
            }
    }
}
