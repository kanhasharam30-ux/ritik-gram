package com.example.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ConversationWithParticipant
import com.example.data.model.UserEntity
import com.example.data.repository.ChatRepository
import com.example.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val conversations: List<ConversationWithParticipant> = emptyList(),
    val discoverUsers: List<UserEntity> = emptyList(),
    val totalUnreadCount: Int = 0,
    val isLoading: Boolean = false
)

enum class NavigationTab {
    HOME, CHATS, SEARCH, PROFILE
}

class HomeViewModel(
    private val currentUserId: String,
    private val chatRepository: ChatRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    private val _selectedTab = MutableStateFlow(NavigationTab.HOME)
    val selectedTab: StateFlow<NavigationTab> = _selectedTab.asStateFlow()

    val conversationsState: StateFlow<List<ConversationWithParticipant>> =
        chatRepository.getConversationsWithParticipants(currentUserId)
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

    val discoverUsersState: StateFlow<List<UserEntity>> =
        userRepository.getAllOtherUsers(currentUserId)
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

    fun selectTab(tab: NavigationTab) {
        _selectedTab.value = tab
    }

    companion object {
        fun provideFactory(
            currentUserId: String,
            chatRepository: ChatRepository,
            userRepository: UserRepository
        ): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return HomeViewModel(currentUserId, chatRepository, userRepository) as T
                }
            }
    }
}
