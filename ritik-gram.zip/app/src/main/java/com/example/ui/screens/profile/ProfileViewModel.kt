package com.example.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.BlockedUserEntity
import com.example.data.model.UserEntity
import com.example.data.repository.AuthRepository
import com.example.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProfileUiState(
    val isUpdating: Boolean = false,
    val updateSuccessMessage: String? = null,
    val errorMessage: String? = null
)

class ProfileViewModel(
    val currentUserId: String,
    private val userRepository: UserRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    val currentUser: StateFlow<UserEntity?> = userRepository.getUserById(currentUserId)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val allUsers: StateFlow<List<UserEntity>> = userRepository.getAllUsers()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val blockedUsers: StateFlow<List<BlockedUserEntity>> = userRepository.getBlockedUsers(currentUserId)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun updateProfile(
        displayName: String,
        bio: String,
        avatarUrl: String,
        phone: String,
        email: String
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isUpdating = true)
            val result = userRepository.updateProfile(user, displayName, bio, avatarUrl, phone, email)
            result.fold(
                onSuccess = {
                    _uiState.value = _uiState.value.copy(
                        isUpdating = false,
                        updateSuccessMessage = "Profile updated successfully! ✨"
                    )
                },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isUpdating = false,
                        errorMessage = error.localizedMessage ?: "Failed to update profile"
                    )
                }
            )
        }
    }

    fun updatePrivacy(lastSeen: String, readReceipts: Boolean, whoCanMessage: String) {
        viewModelScope.launch {
            userRepository.updatePrivacySettings(currentUserId, lastSeen, readReceipts, whoCanMessage)
            _uiState.value = _uiState.value.copy(
                updateSuccessMessage = "Privacy settings updated! 🔒"
            )
        }
    }

    fun unblockUser(blockedUserId: String) {
        viewModelScope.launch {
            userRepository.unblockUser(currentUserId, blockedUserId)
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
        }
    }

    fun switchAccount(userId: String) {
        viewModelScope.launch {
            authRepository.switchAccount(userId)
        }
    }

    fun clearFeedback() {
        _uiState.value = _uiState.value.copy(
            updateSuccessMessage = null,
            errorMessage = null
        )
    }

    companion object {
        fun provideFactory(
            currentUserId: String,
            userRepository: UserRepository,
            authRepository: AuthRepository
        ): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ProfileViewModel(currentUserId, userRepository, authRepository) as T
                }
            }
    }
}
