package com.example.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.MessageEntity
import com.example.data.model.UserEntity
import com.example.data.repository.ChatRepository
import com.example.data.repository.UserRepository
import com.example.util.SampleDataSeeder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatUiState(
    val otherUser: UserEntity? = null,
    val isBlocked: Boolean = false,
    val isBlockedByOther: Boolean = false,
    val isSending: Boolean = false,
    val selectedMediaUrl: String? = null,
    val selectedMediaType: String = "NONE"
)

class ChatViewModel(
    val currentUserId: String,
    val otherUserId: String,
    private val chatRepository: ChatRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    val conversationId = SampleDataSeeder.getConversationId(currentUserId, otherUserId)

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    val messages: StateFlow<List<MessageEntity>> =
        chatRepository.getMessagesForConversation(conversationId)
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

    init {
        loadData()
        markAsRead()
    }

    private fun loadData() {
        viewModelScope.launch {
            userRepository.getUserById(otherUserId).collect { user ->
                _uiState.value = _uiState.value.copy(otherUser = user)
            }
        }
        viewModelScope.launch {
            val blocked = userRepository.isUserBlocked(currentUserId, otherUserId)
            val blockedByOther = userRepository.isUserBlocked(otherUserId, currentUserId)
            _uiState.value = _uiState.value.copy(
                isBlocked = blocked,
                isBlockedByOther = blockedByOther
            )
        }
    }

    fun markAsRead() {
        viewModelScope.launch {
            chatRepository.markConversationRead(conversationId, currentUserId)
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank() && _uiState.value.selectedMediaUrl == null) return
        if (_uiState.value.isBlocked || _uiState.value.isBlockedByOther) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSending = true)
            chatRepository.sendMessage(
                senderId = currentUserId,
                receiverId = otherUserId,
                text = text,
                mediaType = _uiState.value.selectedMediaType,
                mediaUrl = _uiState.value.selectedMediaUrl ?: ""
            )
            _uiState.value = _uiState.value.copy(
                isSending = false,
                selectedMediaUrl = null,
                selectedMediaType = "NONE"
            )
        }
    }

    fun setMedia(url: String, type: String = "IMAGE") {
        _uiState.value = _uiState.value.copy(
            selectedMediaUrl = url,
            selectedMediaType = type
        )
    }

    fun clearMedia() {
        _uiState.value = _uiState.value.copy(
            selectedMediaUrl = null,
            selectedMediaType = "NONE"
        )
    }

    fun setReaction(messageId: String, emoji: String) {
        viewModelScope.launch {
            chatRepository.setReaction(messageId, emoji)
        }
    }

    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            chatRepository.deleteMessage(messageId)
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            chatRepository.clearConversation(conversationId)
        }
    }

    fun toggleBlock() {
        viewModelScope.launch {
            val currentlyBlocked = _uiState.value.isBlocked
            if (currentlyBlocked) {
                userRepository.unblockUser(currentUserId, otherUserId)
            } else {
                userRepository.blockUser(currentUserId, otherUserId)
            }
            _uiState.value = _uiState.value.copy(isBlocked = !currentlyBlocked)
        }
    }

    fun simulateIncomingReply(text: String = "Thanks for your message! Got it on Ritik Gram 👍") {
        viewModelScope.launch {
            chatRepository.simulateReply(
                senderId = otherUserId,
                receiverId = currentUserId,
                replyText = text
            )
        }
    }

    companion object {
        fun provideFactory(
            currentUserId: String,
            otherUserId: String,
            chatRepository: ChatRepository,
            userRepository: UserRepository
        ): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ChatViewModel(currentUserId, otherUserId, chatRepository, userRepository) as T
                }
            }
    }
}
