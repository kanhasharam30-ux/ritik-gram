package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Ritik Gram Signature Palette: Electric Blue, Vivid Purple & Indigo Night
val ElectricBluePrimary = Color(0xFF2563EB)
val ElectricBlueLight = Color(0xFF60A5FA)
val ElectricBlueDark = Color(0xFF1D4ED8)

val NeonPurpleSecondary = Color(0xFF9333EA)
val NeonPurpleLight = Color(0xFFC084FC)
val NeonPurpleDark = Color(0xFF7E22CE)

val AccentPink = Color(0xFFEC4899)
val OnlineGreen = Color(0xFF10B981)
val ReadReceiptBlue = Color(0xFF38BDF8)

// Dark Surfaces
val DarkNavyBackground = Color(0xFF0B0F19)
val DarkNavySurface = Color(0xFF131B2E)
val DarkNavyCard = Color(0xFF1E293B)
val DarkNavyBorder = Color(0xFF334155)

// Light Surfaces
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)

// Text Colors
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

// Chat Bubble Colors
val SenderBubbleColor = Color(0xFF3B82F6)
val ReceiverBubbleDark = Color(0xFF1E293B)
val ReceiverBubbleLight = Color(0xFFE2E8F0)
