package com.example

import com.example.data.model.ConversationEntity
import com.example.util.PasswordHasher
import com.example.util.SampleDataSeeder
import com.example.util.TimeUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testPasswordHashingAndVerification() {
        val rawPassword = "securePassword123"
        val hash = PasswordHasher.hashPassword(rawPassword)

        assertNotEquals(rawPassword, hash)
        assertTrue(PasswordHasher.verifyPassword(rawPassword, hash))
        assertFalse(PasswordHasher.verifyPassword("wrongPassword", hash))
    }

    @Test
    fun testConversationIdDeterministicOrdering() {
        val userA = "user_123"
        val userB = "user_456"

        val convId1 = SampleDataSeeder.getConversationId(userA, userB)
        val convId2 = SampleDataSeeder.getConversationId(userB, userA)

        assertEquals("user_123_user_456", convId1)
        assertEquals(convId1, convId2)
    }

    @Test
    fun testConversationEntityParticipantResolving() {
        val conv = ConversationEntity(
            id = "user1_user2",
            user1Id = "user1",
            user2Id = "user2",
            unreadCountUser1 = 3,
            unreadCountUser2 = 0
        )

        assertEquals("user2", conv.getOtherUserId("user1"))
        assertEquals("user1", conv.getOtherUserId("user2"))
        assertEquals(3, conv.getUnreadCount("user1"))
        assertEquals(0, conv.getUnreadCount("user2"))
    }

    @Test
    fun testTimeUtilsLastSeenPrivacy() {
        val now = System.currentTimeMillis()
        val formattedOnline = TimeUtils.formatLastSeen(now, isOnline = true, privacy = "EVERYONE")
        assertEquals("Online", formattedOnline)

        val formattedNobody = TimeUtils.formatLastSeen(now, isOnline = true, privacy = "NOBODY")
        assertEquals("", formattedNobody)
    }
}
